
export const DecentratwitterAddress = "0x610178dA211FEF7D417bC0e6FeD39F05609AD788"
